"""
MaximizedAttackResult Class
============================

"""

from .attack_result import AttackResult


class MaximizedAttackResult(AttackResult):
    """The result of a successful attack."""
