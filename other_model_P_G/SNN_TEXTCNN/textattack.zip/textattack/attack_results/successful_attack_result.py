"""
SuccessfulAttackResult Class
==============================

"""


from .attack_result import AttackResult


class SuccessfulAttackResult(AttackResult):
    """The result of a successful attack."""
