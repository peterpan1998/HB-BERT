"""
infer sent
^^^^^^^^^^^^
"""


from .infer_sent import InferSent
