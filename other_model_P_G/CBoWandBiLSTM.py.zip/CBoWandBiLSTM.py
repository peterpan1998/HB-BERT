import torch
import torch.nn as nn
from thop import profile, clever_format

# ====== 自定义 Embedding 计数函数 ======
def count_embedding(m, x, y):
    # 参数数量 = 词表大小 * 向量维度
    total_params = m.num_embeddings * m.embedding_dim
    # FLOPs 近似：每个token查表一次，相当于一个embedding_dim访问
    flops = x[0].numel() * m.embedding_dim

    # 与 thop 内部格式兼容（Tensor类型累加）
    m.total_ops += torch.DoubleTensor([flops])
    m.total_params += torch.DoubleTensor([total_params])


# ====== 模型定义 ======
class CBoW(nn.Module):
    def __init__(self, vocab_size=30522, embed_dim=768, num_classes=2):
        super(CBoW, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        self.fc = nn.Linear(embed_dim, num_classes)

    def forward(self, x):
        emb = self.embedding(x)
        avg = emb.mean(dim=1)
        out = self.fc(avg)
        return out


class BiLSTM(nn.Module):
    def __init__(self, vocab_size=30522, embed_dim=768, hidden_size=384, num_classes=2, num_layers=1):
        super(BiLSTM, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim)
        self.lstm = nn.LSTM(embed_dim, hidden_size, num_layers=num_layers,
                            bidirectional=True, batch_first=True)
        self.fc = nn.Linear(hidden_size * 2, num_classes)

    def forward(self, x):
        emb = self.embedding(x)
        out, _ = self.lstm(emb)
        out = out.mean(dim=1)
        out = self.fc(out)
        return out


# ====== 统计函数 ======
def profile_with_embedding(model, inputs):
    # 临时注册 embedding hook
    custom_ops = {nn.Embedding: count_embedding}
    flops, params = profile(model, inputs=(inputs,), custom_ops=custom_ops, verbose=False)
    flops, params = clever_format([flops, params], "%.3f")
    return flops, params


# ====== 主程序 ======
if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    batch_size = 32
    seq_len = 128
    vocab_size = 30522
    num_classes = 2

    inputs = torch.randint(0, vocab_size, (batch_size, seq_len)).to(device)

    for model_name, model in [("CBoW", CBoW(vocab_size, 768, num_classes)),
                              ("BiLSTM", BiLSTM(vocab_size, 768, 384, num_classes))]:
        model = model.to(device)
        flops, params = profile_with_embedding(model, inputs)
        print(f"Model: {model_name}")
        print(f"Parameters: {params} M")
        print(f"FLOPs: {flops} G\n")