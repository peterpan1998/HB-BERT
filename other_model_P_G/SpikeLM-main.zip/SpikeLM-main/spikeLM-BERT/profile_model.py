import json
import torch
from spike_bert import SpikeBertForPreTraining
from transformers import BertConfig
import torchinfo
from fvcore.nn import FlopCountAnalysis
class CustomBertConfig(BertConfig):
    def __init__(self, weight_bits=32, input_bits=2, T=4, quantize_act=True, clip_val=1.0, **kwargs):
        super().__init__(**kwargs)
        self.weight_bits = weight_bits
        self.input_bits = input_bits
        self.T = T
        self.quantize_act = quantize_act
        self.clip_val = clip_val

def main():
    # Create a default BERT configuration
    model_config = CustomBertConfig(
        vocab_size=30522,  # Default BERT vocab size
        hidden_size=768,  # Hidden layer size
        num_hidden_layers=12,  # Number of transformer layers
        num_attention_heads=12,  # Number of attention heads
        intermediate_size=3072,  # Feed-forward layer size
        max_position_embeddings=512  # Maximum sequence length
    )

    # Instantiate the model
    model = SpikeBertForPreTraining(config=model_config).to('cuda')

    # Generate dummy inputs for the model
    batch_size = 1
    seq_length = 128
    dummy_input_ids = torch.randint(0, 30522, (batch_size, seq_length), dtype=torch.long).to('cuda')
    dummy_attention_mask = torch.ones((batch_size, seq_length), dtype=torch.long).to('cuda')
    dummy_token_type_ids = torch.zeros((batch_size, seq_length), dtype=torch.long).to('cuda')

    # Debugging: Run the model forward pass manually
    print("Running model forward pass...")
    try:
        outputs = model(
            input_ids=dummy_input_ids,
            attention_mask=dummy_attention_mask,
            token_type_ids=dummy_token_type_ids
        )
        print("Model forward pass successful.")
        print("Output:", outputs)

        # Calculate parameter count
        total_params = sum(p.numel() for p in model.parameters())
        print(f"Total Parameters: {total_params / 1e6:.2f}M")

        # Calculate FLOPs
        flops = FlopCountAnalysis(model, (dummy_input_ids,))
        print(f"Total FLOPs: {flops.total() / 1e9:.2f}G")

    except Exception as e:
        print("Error during model forward pass:", e)

if __name__ == "__main__":
    main()