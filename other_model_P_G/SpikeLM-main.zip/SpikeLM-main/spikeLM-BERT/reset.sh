rm -rf base_spike
rm -rf wandb

cd spike_ft-10w
rm -rf *out
rm -rf res