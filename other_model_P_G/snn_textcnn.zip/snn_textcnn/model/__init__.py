from .textcnn import SNN_TextCNN
from .ann_model import ANN_TextCNN
from .ann_bilstm import ANN_BiLSTM
from .snn_bilstm import SNN_BiLSTM
from .ann_dpcnn import ANN_DPCNN
from .snn_dpcnn import SNN_DPCNN
from .normal_textcnn import Normal_TextCNN